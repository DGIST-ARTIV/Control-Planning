import csv

f = open('normal_points.csv', 'r', encoding='utf-8')
rdr = csv.reader(f)

# row_count = sum(1 for row in rdr)
x_list = []
y_list = []
for line in rdr:
    x_list.append(float(line[0]))
    y_list.append(float(line[1]))
f.close()

print("x_list", x_list)
print("y_list", y_list)
