#include <iostream>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <time.h>
#include <thread>
#include <cstdio>
#include <stdio.h>
#include <typeinfo>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <cv_bridge/cv_bridge.h>

#include "ros/ros.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Float32MultiArray.h"
#include "sensor_msgs/JointState.h"
#include "sensor_msgs/NavSatFix.h"
#include "visualization_msgs/MarkerArray.h"
#include "geometry_msgs/Twist.h"

#define _USE_MATH_DEFINES

using namespace cv;

const float k = 0.5;
const float dt = 0.1;
const float L = 2.7;
const float max_steer = 35.5 * M_PI / 180;

double latitude = 0.0;
double longitude = 0.0;
double gpsyaw = 0.0;
double gpsvel = 0.0;
int ioniqsteer = 0;
int erpsteer = 0;
float velocity = 0;

double prev_latitude = 1.0;
double prev_longitude = 1.0;
double prev_gpsyaw = 1.0;
double prev_gpsvel = 1.0;
int prev_ioniqsteer = 1;
int prev_erpsteer = 1;
float prev_velocity = 1.0;

double prev_time = 0;
double prev_error = 0;
double del_time = 0;
double error_p = 0;
double error_i = 0;
double error_d = 0;
double pid_out = 0;
float cruise_speed = 5.0;

bool show_animation = true;

int input_accel, input_brake, input_steer;

std::vector<float> x_coords, y_coords;
std::vector<float> vel_vec;

class State{
public:
	float state_x;
	float state_y;
	float state_yaw;
	float state_v;

	State(float x, float y, float yaw, float v){
		state_x = x;
		state_y = y;
		state_yaw = yaw;
		state_v = v;
	}

	void update(float delta){
		if(delta > max_steer){
			delta = max_steer;
		}
		else if(delta < -max_steer){
			delta = - max_steer;
		}
		state_x = 0;
		state_y = 0;
		state_yaw = M_PI/2;
		state_v = velocity;
	}
};

State state(0, 0, 0, 0);

void PID(int& val_1, int& val_2);
void stanley_control(State state, std::vector<float> cx, std::vector<float> cy, std::vector<float> cyaw, int last_target_index, double& val_1, int& val_2);
float normalize_angle(float angle);
int find_smallest_idx(std::vector<float> vec_list);
void calc_target_index(State state, std::vector<float> cx, std::vector<float> cy, int& val_1, float& val_2);
std::vector<float> calc_spline_course(std::vector<float> vec_x, std::vector<float> vec_y);
void gpsvelCallback(const std_msgs::Float64::ConstPtr& msg);
void ioniqinfoCallback(const std_msgs::Float32MultiArray::ConstPtr& msg);
void jointCallback(const sensor_msgs::JointState::ConstPtr& msg);
void pathCallback(const visualization_msgs::MarkerArray::ConstPtr& msg);
void publishing(ros::Publisher cmd_acc, ros::Publisher cmd_brk, ros::Publisher cmd_ste, std_msgs::Int16 msg1, std_msgs::Int16 msg2, std_msgs::Int16 msg3);
void subscribing();

void PID(int& val_1, int& val_2){
	float cur_time = time(NULL);
	float del_time = cur_time - prev_time;

	float k_p = 14.0;
	float k_i = 0.25;
	float k_d = 1.0;
	int windup_guard = 70;
	int i;

	error_p = cruise_speed - velocity;
	error_i += error_p * (del_time);

	if (error_i < -windup_guard){
		error_i = -windup_guard;
	}
	else if(error_i > windup_guard){
	    error_i = windup_guard;
	}

	error_d = (error_p - prev_error)/del_time;
	pid_out = k_p*error_p + k_i*error_i + k_d*error_d;
	prev_error = error_p;
	prev_time = cur_time;

	if(pid_out > 0){
		for(i = 0; i < 858; i++){
			if(i <= pid_out && i+1 > pid_out){
				int gaspedal = 800 + 10*i;
				if(gaspedal >= 3000){
					gaspedal = 3000;
					val_1 = gaspedal;
					val_2 = 0;
				}
				else{
					val_1 = gaspedal;
					val_2 = 0;
				}
			}
		}
	}
	else if(pid_out < 0){
		for(i = 0; i < 2551; i++){
			if(i <= abs(pid_out) && i+1 > abs(pid_out)){
				val_1 = 0;
				val_2 = 2700+10*i;
			}
		}
	}
	else{
		val_1 = 0;
		val_2 = 0;
	}
}

void stanley_control(State state, std::vector<float> cx, std::vector<float> cy, std::vector<float> cyaw, int last_target_index, double& val_1, int& val_2){
	int idx_val;
	float axle_val;
	calc_target_index(state, cx, cy, idx_val, axle_val);
	int current_target_idx = idx_val;
	float error_front_axle = axle_val;
	double theta_e, theta_d, delta;

	if(last_target_index >= current_target_idx){
		current_target_idx = last_target_index;
	}

  // 추후 cyaw[current_target_idx+2] 수정 필요
	std::cout<<"cyaw[current_target_idx+2]: "<<cyaw[current_target_idx+2]<<std::endl;
	std::cout<<"state.state_yaw "<<state.state_yaw<<std::endl;

  // // 추후 cyaw[current_target_idx+2] 수정 필요
	theta_e = normalize_angle(cyaw[current_target_idx+2] - state.state_yaw);

	std::cout<<"error_front_axle!!!!!!!: "<<error_front_axle<<std::endl;
	std::cout<<"k!!!!!!!!!!: "<<k<<std::endl;
	std::cout<<"state.state_v: "<<state.state_v<<std::endl;

	theta_d = atan2(k * (error_front_axle), state.state_v);

  std::cout<<"theta_e: "<<theta_e<<std::endl;
	std::cout<<"theta_d: "<<theta_d<<std::endl;

	delta = theta_e + theta_d;

	val_1 = delta;
	val_2 = current_target_idx;
}

float normalize_angle(float angle){
	while(angle > M_PI){

		angle -= 2.0 * M_PI;
	}
	while(angle < -M_PI){
		angle += 2.0 * M_PI;
	}

	return angle;
}

int find_smallest_idx(std::vector<float> vec_list){ //return smallest value's index
	int i, j;
	float smallest_val;
	smallest_val = 0.0;

	for (i = 0; i < vec_list.size() - 1; ++i){
		if (smallest_val == 0.0){
			smallest_val = vec_list[0];
		}
		if (smallest_val > vec_list[i]){
			smallest_val = vec_list[i];
		}
	}
	for (j = 0; j < vec_list.size(); ++j){
		if (smallest_val == vec_list[j]){
			return j;
		}
	}
}

void calc_target_index(State state, std::vector<float> cx, std::vector<float> cy, int& val_1, float& val_2){
	float fx, fy, error_front_axle;
	int target_idx, i;
	std::vector<float> dx, dy, d;
	float front_axle_vec[2] = {-cos(state.state_yaw + M_PI/2), -sin(state.state_yaw + M_PI/2)};

	fx = state.state_x + L*cos(state.state_yaw);
	fy = state.state_y * L*sin(state.state_yaw);

	for(i = 0; i < cx.size(); i++){
		dx.push_back(fx - cx[i]);
	}
	for(i = 0; i < cy.size(); i++){
		dy.push_back(fy - cy[i]);
	}
	for(i = 0; i < cx.size(); i++){
		d.push_back(hypot(dx[i], dy[i]));
	}

	target_idx = find_smallest_idx(d);

	// dx[target_idx] 수정 필요
	//error_front_axle = dx[target_idx] * front_axle_vec[0] + dy[target_idx] * front_axle_vec[1];
	error_front_axle = (dx[target_idx] + 150)/10 * front_axle_vec[0] + dy[target_idx] * front_axle_vec[1];

	std::cout<<"dx[target_idx]: "<<(dx[target_idx] + 150)/10<<std::endl;
  std::cout<<"front_axle_vec[0]: "<<front_axle_vec[0]<<std::endl;
	std::cout<<"dy[target_idx]: "<<dy[target_idx]<<std::endl;
	std::cout<<"front_axle_vec[1]: "<<front_axle_vec[1]<<std::endl;

	val_1 = target_idx;
	val_2 = error_front_axle;
}

std::vector<float> calc_spline_course(std::vector<float> vec_x, std::vector<float> vec_y){
	int i;
	std::vector<float> yaw_vec;
	float line_1_gradient, line_2_gradient, avg_gradient, avg_yaw;

	for(i = 1; i < vec_x.size() - 1; i++){
		line_1_gradient = (vec_y[i] - vec_y[i-1])/(vec_x[i] - vec_x[i-1]);
		line_2_gradient = (vec_y[i+1] - vec_y[i])/(vec_x[i+1] - vec_x[i]);
		avg_gradient = (line_1_gradient + line_2_gradient)/2;
		avg_yaw = atan2(avg_gradient, 1);

		if (avg_yaw > 0){
			avg_yaw = avg_yaw;
		}
		else if (avg_yaw < 0){
			avg_yaw = avg_yaw + M_PI;
		}
		yaw_vec.push_back(avg_yaw);
	}

	return yaw_vec;
}

void gpsvelCallback(const std_msgs::Float64::ConstPtr& msg){
	//std::cout<<"GPSCALLBACK!!!!!!!!!!!!"<<std::endl;
	gpsvel = msg->data;
}

void ioniqinfoCallback(const std_msgs::Float32MultiArray::ConstPtr& msg){
	//std::cout<<"IONIQCALLBACK"<<std::endl;
	ioniqsteer = msg->data[3];
}

void jointCallback(const sensor_msgs::JointState::ConstPtr& msg){
	//std::cout<<"JOINTCALLBACK"<<std::endl;
	velocity = msg->velocity[0];
}

void pointCallback(const std_msgs::Float32MultiArray::ConstPtr& msg){
	std::vector<float> local_x, local_y, yaw_vec;
	int i, last_idx, accel_data, brake_data, target_idx_1, target_idx_2;
	int len_val = msg->data.size()/2;
	clock_t start, end;
	float error_front_axle, raw_steer;
	double di, result;
	char text_input_1[] = "Steer : ";
	char text_input_2[] = "Speed : ";

	start = clock();

	if (len_val >2){
		for(i = 0; i < len_val; i++){
			local_x.push_back(msg->data[i]);
			local_y.push_back(msg->data[i+len_val]);
		}
		x_coords = local_x;
		y_coords = local_y;

		/*
		for(int i=0; i<x_coords.size(); i++){
			std::cout<<x_coords[i]<<std::endl;
		}

		for(int i=0; i<y_coords.size(); i++){
			std::cout<<y_coords[i]<<std::endl;
		}
		*/

		//state = State(0, 0, max_steer, 0);
		last_idx = x_coords.size() - 1;

		PID(accel_data, brake_data);
		input_accel = accel_data;
		input_brake = brake_data;
		yaw_vec = calc_spline_course(x_coords, y_coords);

	  // yaw_vec 출력
		/*
		for(int i=2; i<yaw_vec.size(); i++){
			std::cout<<"yaw_vec: "<<yaw_vec[i]<<std::endl;
		}
		*/

		calc_target_index(state, x_coords, y_coords, target_idx_1, error_front_axle);
		stanley_control(state, x_coords, y_coords, yaw_vec, target_idx_1, di, target_idx_2);
		state.update(di);


	  std::cout<<"-----------------------------------"<<std::endl;
		std::cout<<"di: "<<di<<std::endl;
		std::cout<<"target_idx_2: "<<target_idx_2<<std::endl;
		std::cout<<"error_front_axle: "<<error_front_axle<<std::endl;

		if(isnan(di)){
			di = 0.0;
		}

		raw_steer = (int)round(-di * (180 / M_PI * (525 / 35.75)));

		if(raw_steer > -530 && raw_steer < 530){
			input_steer = raw_steer;
		}
		else if(raw_steer <= -530){
			input_steer = -530;
		}
		else if(raw_steer >= 530){
			input_steer = 530;
		}

		std::cout<<"input_steer: "<<input_steer<<std::endl;

		//deaccel_speed = deacceleration(di);
		vel_vec.push_back(state.state_v);

		end = clock();
		result = (double)(end - start);
		std::cout<<"Time Delay : "<<result<<std::endl;

	  // 시각화
		Mat stanley_img = Mat::zeros(300, 300, CV_8UC3);

		for (i = 0; i < x_coords.size(); i++){
			//std::cout<<x_coords[x_coords.size()-1]<<std::endl;
			//std::cout<<y_coords[y_coords.size()-1]<<std::endl;
			//std::cout<<x_coords[i]+150-x_coords[x_coords.size()-1]<<std::endl;
			//std::cout<<y_coords[i]+300-y_coords[y_coords.size()-1]<<std::endl;
			circle(stanley_img, Point(x_coords[i]+150-x_coords[x_coords.size()-1], y_coords[i]+300-y_coords[y_coords.size()-1]), 3, Scalar(0, 255, 0), FILLED, LINE_8);
			//circle(stanley_img, Point(x_coords[i], y_coords[i]), 3, Scalar(0, 255, 0), FILLED, LINE_8);
		}
		circle(stanley_img, Point(150, 300), 3, Scalar(0, 0, 255), FILLED, LINE_8);
	  //circle(stanley_img, Point(x_coords[target_idx_2+30], y_coords[target_idx_2+30]), 3 , Scalar(255, 0, 0), FILLED, LINE_8);

		putText(stanley_img, text_input_1 + std::to_string(input_steer), Point(5, 30), 2, 0.5, Scalar(255, 255, 255));
		putText(stanley_img, text_input_2 + std::to_string(velocity), Point(5, 50), 2, 0.5, Scalar(255, 255, 255));

		imshow("Result", stanley_img);
		waitKey(1);
	}
}

void publishing(ros::Publisher cmd_acc, ros::Publisher cmd_brk, ros::Publisher cmd_ste, std_msgs::Int16 msg1, std_msgs::Int16 msg2, std_msgs::Int16 msg3){
	while(ros::ok()){
		msg1.data = input_accel;
		msg2.data = input_brake;
		msg3.data = input_steer;
		cmd_acc.publish(msg1);
		cmd_brk.publish(msg2);
		cmd_ste.publish(msg3);
		sleep(0.1);
	}
}

void subscribing(){
	ros::spin();
}

int main(int argc, char * argv[]){
	std::cout<<"Starting ROS..."<<std::endl;
	ros::init(argc, argv, "stanley_method");
	ros::NodeHandle n;
	ros::Publisher accelPub_ = n.advertise<std_msgs::Int16>("dbw_cmd/Accel", 1000);
	ros::Publisher brakePub_ = n.advertise<std_msgs::Int16>("dbw_cmd/Brake", 1000);
	ros::Publisher steerPub_ = n.advertise<std_msgs::Int16>("dbw_cmd/Steer", 1000);
	ros::Subscriber gpsvelSub = n.subscribe("gps_spd", 1000, gpsvelCallback);
	ros::Subscriber IoniqSub = n.subscribe("Ioniq_info", 1000, ioniqinfoCallback);
	ros::Subscriber JointSub = n.subscribe("Joint_state", 1000, jointCallback);
	ros::Subscriber points_sub = n.subscribe("enetsad/centerPt", 1000, pointCallback);

	std_msgs::Int16 msg_1;
	std_msgs::Int16 msg_2;
	std_msgs::Int16 msg_3;
	std::cout<<"Starting Threading...1"<<std::endl;
	std::thread t1(publishing, accelPub_, brakePub_, steerPub_, msg_1, msg_2, msg_3);
	std::cout<<"Starting Threading...2"<<std::endl;
	std::thread t2(subscribing);
	std::cout<<"Starting Threading...3"<<std::endl;
	t1.join();
	std::cout<<"Starting Threading...4"<<std::endl;
	t2.join();
	std::cout<<"Starting Threading...5"<<std::endl;
	return 0;
}
