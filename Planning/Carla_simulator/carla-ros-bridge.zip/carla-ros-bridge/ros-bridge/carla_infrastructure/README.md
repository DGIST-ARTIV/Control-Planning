# ROS Infrastructure

The reference Carla client `carla_infrastructure` can be used to spawn infrastructure sensors.
